case `uname -s` in
AIX)
    export CFLAGS=-maix64
    ;;
esac

